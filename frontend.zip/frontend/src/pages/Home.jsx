// src/pages/Home.jsx
import React from 'react';
import { Carousel } from 'react-responsive-carousel';

function Home() {
  return (
    <Carousel>
      <div>Slide 1</div>
      <div>Slide 2</div>
      <div>Slide 3</div>
    </Carousel>
  );
}

export default Home;